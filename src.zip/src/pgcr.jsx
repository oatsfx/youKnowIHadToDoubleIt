import { hasSelectionSupport } from '@testing-library/user-event/dist/utils';
import React, { useState, useEffect } from 'react';

import './App.css';
import PGCRPlayerCard from './PGCRPlayerCard';

const API_KEY = '30ac6692ced14a55b3f6a2862093e021';
const BUNGIE_ENDPOINT = "https://www.bungie.net";
const BUNGIE_ENDPOINT_PGCRS = "https://stats.bungie.net";

var activityHash;

const PGCR = () => {
  const parameters = new URLSearchParams(window.location.search);
  const PGCR_ID = parameters.get("id");

  const [players, setPlayers] = useState([]);
  const [activityHashes, setActivityHashes] = useState([]);
  const [activityHash, setActivityHash] = useState(0);

  const [badges, setBadges] = useState([]);

  const getPGCR = async (ID) => {
    const response = await fetch(`${BUNGIE_ENDPOINT_PGCRS}/Platform/Destiny2/Stats/PostGameCarnageReport/${ID}`, { headers: {"X-API-Key": API_KEY} });
    const item = await response.json();
    console.log(item);
    setPlayers(item.Response.entries);
    setActivityHash(item.Response.activityDetails.directorActivityHash);

    var highestKd = {characterId: null, characterHash: 0, value: -1};
    var highestDeaths = {characterId: null, characterHash: 0, value: 0};
    var highestPrecision = {characterId: null, characterHash: 0, value: -1};

    console.log(players.length);
    item.Response.entries.forEach((player) => {
      if (player.values.completed.basic.value !== 0){
        const tag = `${player.player.destinyUserInfo.bungieGlobalDisplayNameCode}`;
        const bungieName = `${player.player.destinyUserInfo.bungieGlobalDisplayName}#${tag.padStart(4, '0')}`;
        console.log(bungieName);
        if (player.values.killsDeathsRatio.basic.value.toFixed(2) >= highestKd.value) {
          console.log(player.values.killsDeathsRatio.basic.value.toFixed(2));
          highestKd = {characterId: player.characterId, value: player.values.killsDeathsRatio.basic.value.toFixed(2)};
        }

        if (player.values.deaths.basic.value > highestDeaths.value) {
          highestDeaths = {characterId: player.characterId, value: player.values.deaths.basic.value};
        }

        const precisionRatio = player.extended.values.precisionKills.basic.value / player.values.kills.basic.value;
        if (precisionRatio >= highestPrecision.value){
          highestPrecision = {characterId: player.characterId, value : precisionRatio.toFixed(2)};
        }
      }
    });

    const kdBadge = {characterId: highestKd.characterId, badgeName: "Most Efficient"};
    const deathsBadge = {characterId: highestDeaths.characterId, badgeName: "Most Deaths"};
    const precisionBadge = {characterId: highestPrecision.characterId, badgeName: "Most Precise"};
    var newBadges = [];
    newBadges.push(kdBadge, deathsBadge, precisionBadge);

    console.log(newBadges);

    setBadges(newBadges);
  }

  /*const getManifest = async () => {
    await fetch(`${BUNGIE_ENDPOINT}/Platform/Destiny2/Manifest`, { headers: {"X-API-Key": API_KEY} })
      .then(response => response.json())
      .then(item => fetch(`${BUNGIE_ENDPOINT}${item.Response.jsonWorldComponentContentPaths.en["DestinyActivityDefinition"]}`))
      .then(response => response.json())
      .then(item => {
        setActivityHashes(item);
      })
      .then(setActivityName(activityHashes[activityHash].displayProperties.name));
  }*/

  useEffect(() => {
    //getManifest();
    getPGCR(PGCR_ID);
  }, []);

  return (
    <div className="app">
      <div className="head">
        <h1>yourmom.report</h1>
      </div>
      <h2 className="name">Activity: {activityHash}</h2>
      <div className="pgcr-container">
        <div className="column" key="1">
          {players.slice(0, Math.ceil(players.length/2)).map((player) => (
            <PGCRPlayerCard player={player} badges={badges} />
          ))}
        </div>
        {players.length > 3 ?
          <div className="column" key="2">
            {players.slice(Math.ceil(players.length/2), players.length).map((player) => (
              <PGCRPlayerCard player={player} badges={badges} />
            ))}
          </div> :
          []
        }
      </div>
    </div>
  );
}

export default PGCR;
