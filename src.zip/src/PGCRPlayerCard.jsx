import React, { useEffect, useState } from 'react';
const BUNGIE_ENDPOINT = "https://www.bungie.net";
const DestinyClass = {
    0: "Titan",
    1: "Hunter",
    2: "Warlock",
}

const PGCRPlayerCard = ({ player, badges }) => {
  useEffect(() => {
    const cardDiv = document.getElementById(player.characterId);
    if (player.values.completed.basic.value === 0){
      cardDiv.classList.add('pgcr-player-dnf');
    }
  }, []);
  const tag = `${player.player.destinyUserInfo.bungieGlobalDisplayNameCode}`;
  const bungieName = `${player.player.destinyUserInfo.bungieGlobalDisplayName}#${tag.padStart(4, '0')}`;
  return (
      <div className="pgcr-player" id={player.characterId}>
        <img src={BUNGIE_ENDPOINT+player.player.destinyUserInfo.iconPath}></img>
        
        <div className="details">
          <h3>{player.player.destinyUserInfo.bungieGlobalDisplayName}<span className="bungie-tag">#{tag.padStart(4 ,'0')}</span> <span className="light">{player.player.lightLevel}</span></h3>
        </div>

        <div className="badges">

          {badges.map((badge) => (
            badge.characterId === player.characterId ?
            <div className="badge">
              <span>{badge.badgeName}</span>
            </div> : []
          ))}

          {
            player.values.completed.basic.value === 0 ? 
            <div className="badge">
              <span className="dnf">DNF</span>
            </div> : []
          }
          
        </div>

        <div className="stats">
          <div className="stat">
            <p>{player.values.kills.basic.value}</p><p className="stat-name">KILLS</p>
          </div>
          <div className="stat">
            <p>{player.values.deaths.basic.value}</p><p className="stat-name">DEATHS</p>
          </div>
          <div className="stat">
            <p>{player.values.killsDeathsRatio.basic.value.toFixed(2)}</p><p className="stat-name">K/D RATIO</p>
          </div>
          <div className="stat">
            <p>{player.values.activityDurationSeconds.basic.displayValue}</p><p className="stat-name">TIME</p>
          </div>
        </div>
      </div>
  )
}
export default PGCRPlayerCard;