import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import PGCR from "./pgcr";

import './App.css';
import GuardianCard from './GuardianCard';

const API_KEY = '30ac6692ced14a55b3f6a2862093e021';
const BUNGIE_ENDPOINT = "https://www.bungie.net";
var MEM_TYPE = "3";
var MEM_ID = "4611686018471482002";
var components = "100,200";

function App(){
  const [guardians, setGuardians] = useState([]);
  const [charIds, setCharIds] = useState([]);

  const getCharacters = async (memType, memId) => {
    const response = await fetch(`${BUNGIE_ENDPOINT}/Platform/Destiny2/${memType}/Profile/${memId}/?components=${components}`, { headers: {"X-API-Key": API_KEY} });
    const item = await response.json();

    console.log(item);
    setGuardians(item.Response.characters.data);
    setCharIds(item.Response.profile.data.characterIds);
  }

  useEffect(() => {
    getCharacters(MEM_TYPE, MEM_ID);
  }, []);

  return (
    <div className="app">
      <div className="head">
        <h1>Look it's your Guardians...</h1>
      </div>
      
      <div className="mid">
        <div className="search">
          <input 
            placeholder="Search Guardian#0000"
          />
        </div>
      </div>

      <div className="guardian-container">
        <h2 className="name">OatsFX<span className="bungie-tag">#5630</span></h2>
        {charIds.map((charId) => (
          <GuardianCard guardian={guardians[charId]} />
        ))}
      </div>
    </div>
  );
}

export default App;
